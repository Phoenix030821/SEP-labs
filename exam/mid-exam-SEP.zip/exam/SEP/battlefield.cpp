#include "battlefield.h"

// find path in this function
// you can add other functions to solve this problem
// you should print the path if you can find one
// if you can find one, return true, otherwise false
bool BattleField::findPath(){
    return false;
}

