#ifndef BOARD_H
#define BOARD_H
#endif // BOARD_H

// Don't change, width = N, height = N
#define N 100
class BattleField
{
public:
    int field[N][N];
    // find path in this function
    bool findPath();
};
