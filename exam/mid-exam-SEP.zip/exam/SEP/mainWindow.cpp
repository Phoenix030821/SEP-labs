#include "mainWindow.h"
#include <QPainter>
#include <QKeyEvent>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
{
    // set window title
    setWindowTitle(tr("Find Way To Exit!!!"));
    // @TODO write your codes here
}

void MainWindow::load_data(){
    // @TODO write your codes here
}

void MainWindow::keyPressEvent(QKeyEvent *event){
    // @TODO write your codes here
}


void MainWindow::paintEvent(QPaintEvent *)
{
    // @TODO write your codes here
}

